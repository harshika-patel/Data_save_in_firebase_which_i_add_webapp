import 'https://cdnjs.cloudflare.com/ajax/libs/framework7/5.7.10/js/framework7.bundle.js';
import "https://cdnjs.cloudflare.com/ajax/libs/firebase/7.16.0/firebase-app.min.js";
import "https://cdnjs.cloudflare.com/ajax/libs/firebase/7.16.0/firebase-database.min.js";
import "https://cdnjs.cloudflare.com/ajax/libs/firebase/7.16.1/firebase-auth.min.js";
import app from "./F7App.js";

const $$ = Dom7;
$$("#tab2").on("tab:show", () => {
    const sUser = firebase.auth().currentUser.uid;
    firebase.database().ref("groceries/" + sUser).once("value").then(snapshot => {
        const oItems = snapshot.val();
        if (oItems) {
            const aKeys = Object.keys(oItems);
            $$("#groceryList").html("");

            aKeys.forEach((itemKey, index) => {
                const item = oItems[itemKey];
                let sCard = `
                <div class="card">
                    <div class="card-content item-name" style="font-weight: bold;">${item.item}</div>
                    <div class="card-content">
                        <img src="${item.image}" alt="Item Image">
                    </div>
                    <div class="card-content item-costS" style="font-weight: bold;">${item.cost}</div>
                    <div class="card-footer">
                        <button class="button button-active buy-btn" data-key="${itemKey}">I bought this</button>
                        <button class="button button-active delete-btn" data-key="${itemKey}">I don't need this</button>
                    </div>
                </div>`;

                $$("#groceryList").append(sCard);

                // Add strike-through style if item has been purchased
                if (item.datePurchased) {
                    $$(".card-content.item-name").eq(index).addClass("purchased");
                }
            });

            // Add click event listeners for buy and delete buttons
            $$(".buy-btn").on("click", function() {
                const itemKey = $$(this).data("key");
                const itemRef = firebase.database().ref("groceries/" + sUser + "/" + itemKey);
                itemRef.update({ datePurchased: new Date().toISOString() });
                $$(this).closest(".card").find(".card-content.item-name").addClass("purchased");
            });

            $$(".delete-btn").on("click", function() {
                const itemKey = $$(this).data("key");
                const itemRef = firebase.database().ref("groceries/" + sUser + "/" + itemKey);
                itemRef.remove();
                $$(this).closest(".card").remove();
            });
        } else {
            console.error("oItems is null or undefined");
        }
    }).catch(error => {
        console.error("Error fetching groceries:", error);
    });
});



$$(".my-sheet").on("submit", e => {
    //submitting a new note
    e.preventDefault();
    const oData = app.form.convertToData("#addItem");
    const sUser = firebase.auth().currentUser.uid;
    const sId = new Date().toISOString().replace(".", "_");
    firebase.database().ref("groceries/" + sUser + "/" + sId).set(oData);
    app.sheet.close(".my-sheet", true);
});