const config = {
    apiKey: "AIzaSyAEt3CqMordCB0iIFnK2M1QFXSBgmAu5aU",
  authDomain: "card-shop-cb001.firebaseapp.com",
  databaseURL: "https://card-shop-cb001-default-rtdb.firebaseio.com",
  projectId: "card-shop-cb001",
  storageBucket: "card-shop-cb001.appspot.com",
  messagingSenderId: "295558603545",
  appId: "1:295558603545:web:b2998ac6cc316e99bd1b88",
  measurementId: "G-QSYLR8KYS2"
  };
  
  export default config;
  